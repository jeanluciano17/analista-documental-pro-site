# Base especializada — Divisão de Gestão de Bens Imóveis da PMESP (DF)

## Escopo e cautelas
Usar esta referência em pedidos sobre gestão imobiliária da PMESP, cadastro patrimonial, SGI, regularização de ocupação, locação, despesas, conservação, obras e instrução de processos. Esta base sintetiza documentos fornecidos pelo usuário; não é organograma oficial nem substitui atos internos vigentes, o processo SEI integral, parecer técnico ou manifestação jurídica.

Separar sempre: (1) conteúdo expresso dos documentos; (2) requisitos normativos cuja vigência/aplicabilidade foi verificada; (3) inferências/recomendações; (4) itens não verificáveis. Não atribuir à Divisão uma competência formal sem ato organizacional atual que a confirme.

## Estrutura organizacional: nomenclaturas e limites
- A I-38-PM, 2ª edição (2017), art. 9º, identifica a antiga Diretoria de Finanças e Patrimônio (DFP) como órgão de direção setorial do patrimônio imobiliário da Unidade Orçamentária PM; o art. 10 descreve suas atribuições.
- O Decreto Estadual nº 65.096/2020 é referência de organização da PMESP e identifica Diretoria de Finanças (DF) e Diretoria de Logística (DL) em âmbitos distintos. Conferir versão consolidada, alterações e atos internos posteriores antes de descrever a cadeia hierárquica atual.
- Expedientes administrativos de 2026 fornecidos pelo usuário usam a denominação “Divisão de Gestão de Bens Imóveis” e mostram participação em diligências de processos de locação. Um expediente indica (11) 3327-7879 e (11) 3327-7678; contatos podem estar desatualizados.
- Não afirmar organograma completo, seções internas, subordinação atual, nomes de responsáveis, delegações, prazos internos ou sistemas não documentados sem fonte oficial atual.

## Atribuições descritas na I-38-PM
A instrução distribui funções entre órgão setorial, subsetoriais, detentores e órgão técnico; não se deve presumir que todas sejam executadas diretamente pela Divisão.

### Órgão de direção setorial — arts. 9º e 10 (I-38-PM, 2017)
O texto atribui à antiga DFP, entre outras funções: preparar proposta do Plano Diretor de Obras e Serviços (PDOS) e critérios de prioridade; gerir documentos e cadastro geral dos imóveis compatível com SGI; fiscalizar/acompanh ar ocupação após ato normativo de destinação/recebimento; auditar ocupações, cadastros e uso; propor procedimentos de manutenção e controle de custos; produzir relatórios trimestrais cadastrais (nos imóveis locados, identificação contratual, prazo e valor); fiscalizar identidade visual das OPM; determinar interdição de área/edificação com risco mediante parecer/laudo técnico; e encaminhar informações sobre termos de recebimento provisório/definitivo. Tratar como atribuições do órgão setorial da norma de 2017, não como prova de delegação atual à Divisão.

### Órgãos subsetoriais — arts. 11 e 12
A I-38-PM prevê formulação de propostas de obras/serviços, atualização de cadastros e SGI, atualização de registros imobiliários, orientação e auditoria de unidades subordinadas, gestão de despesas e controle de contratos de locação das próprias sedes e das OPM subordinadas.

### Órgãos detentores — arts. 13 e 14
As OPM que ocupam imóveis devem formular pedidos de obras/serviços, executar manutenção preventiva de primeiro escalão, promover uso racional de água/energia/telefonia/gás e comunicar necessidades emergenciais ao órgão subsetorial.

### Órgão técnico
Engenharia, vistoria, projetos, segurança física, reformas e pareceres técnicos cabem ao órgão técnico competente, conforme regras vigentes. Gestão administrativa/patrimonial não substitui laudos de profissionais habilitados.

## Escopo material da gestão imobiliária
A I-38-PM, art. 3º, trata de imóveis próprios do Estado destinados à PMESP, imóveis cedidos ou permitidos para uso, comodatos e outras formas de ocupação previstas, bem como imóveis locados e situações que exijam regularização. As tarefas distribuídas pelo sistema abrangem identificação/cadastro, legitimidade e destinação da ocupação, contratos e prazos, custos e despesas, conservação, planejamento de obras e auditoria patrimonial.

## SGI — Sistema de Gerenciamento de Imóveis
A I-38-PM prevê cadastro geral compatível com o SGI e atualização subsetorial dos imóveis sob responsabilidade. O Manual de Locação de Imóveis SSP/SP (2026) prevê no passo 20 inserção/atualização do imóvel no SGI, registros imobiliários pertinentes e manutenção dos dados durante a vigência contratual.

Controles recomendados: comparar endereço, unidade beneficiada, tipo de ocupação e dados contratuais com as peças SEI; confirmar números de cadastro apenas por fonte documental; atualizar mudanças de ocupação, valor, prazo e unidade; não presumir que cadastro SGI, sozinho, legaliza ocupação ou substitui ato/contrato; distinguir SGI do Sistema de Gestão do Patrimônio Imobiliário do Estado (SGPI), sem tratá-los automaticamente como sinônimos.

## Locação e pontos de controle
Aplicar também `locacao-imoveis-pmesp.md`. O Manual SSP/SP 2026 abrange nova locação, renovação, prorrogação, revisão, reajuste e alterações contratuais. Seu roteiro de 20 etapas contempla: (1) justificativa da necessidade; (2) DFD; (3) disponibilidade de imóvel público; (4) documentação/caracterização do imóvel; (5) ETP; (6) TR; (7) riscos; (8) avaliação locatícia; (9) documentos do locador; (10) regularidade do locador; (11) justificativa de inexigibilidade; (12) minuta; (13) orçamento/reserva; (14) parecer referencial e declaração, se aplicáveis; (15) Comitê Gestor, quando exigido; (16) conferência final; (17) DTP; (18) manifestações/autorizações; (19) contrato; (20) SGI e registros.

Controles essenciais: comprovar busca de imóvel público vago e adequado; justificar escolha e preço com pesquisa/avaliação; manter coerência entre DFD, ETP, TR, proposta, orçamento e minuta; conferir matrícula/título, planta, cadastro municipal, memorial, IPTU e certidões pertinentes; avaliar acessibilidade com manifestação técnica, adaptações, custos, responsáveis e prazos; usar minuta compatível com parecer referencial vigente; distinguir CPI de Comitê Gestor; não afirmar anuência sem documento; atualizar certidões, remover duplicidades e relacionar documentos com links SEI no encaminhamento.

A Lei 14.133/2021, art. 74, V e §5º, é referência para inexigibilidade de locação, incluindo avaliação prévia, certificação de inexistência de imóvel público vago/adequado, singularidade e vantagem. Verificar requisitos e orientação jurídica vigentes no caso concreto. O Manual 2026 recomenda iniciar nova contratação, renovação ou prorrogação preferencialmente com antecedência de 180 dias; tratar como orientação de planejamento e confirmar o fim do contrato.

## Evidência processual
Classificar cada requisito como: **Comprovado no documento examinado**, **Relatado, mas não verificado**, **Pendente**, **Parcialmente atendido**, **Não verificável** ou **Não aplicável (justificar)**. A menção num ofício não prova que a peça esteja juntada, válida, suficiente ou aprovada. A ausência de menção no ofício não prova ausência no processo SEI completo.

## Órgãos e instâncias que podem participar
Conforme modalidade, etapa, valor e alçada, o fluxo pode envolver unidade demandante, gestão imobiliária, órgão técnico, DTP, setores financeiros/orçamentários, PGE/área jurídica, Conselho do Patrimônio Imobiliário (CPI), Comitê Gestor de Gastos Públicos e autoridade competente. Não afirmar que todos participam de todos os processos nem que a Divisão decide sozinha. O Manual SSP/SP 2026 prevê submissão prévia à DTP no fluxo nele descrito; verificar versão atual e instruções vigentes.

## Despesas, manutenção e obras
A I-38-PM trata de água, energia, telefonia, gás, condomínio e taxas/contribuições pertinentes, controle de custos e relatórios. As responsabilidades são distribuídas: órgão subsetorial gerencia despesas e contratos de unidades subordinadas; órgão detentor executa manutenção preventiva de primeiro escalão; obras/intervenções técnicas seguem autorizações e pareceres aplicáveis. Não atribuir pagamento, contratação ou execução diretamente à Divisão sem evidência específica.

## Fontes e verificação
- I-38-PM, Instruções para Administração de Bens Imóveis, 2ª edição (2017), especialmente arts. 3º, 7º–14, 83–93, 102 e disposições sobre despesas/obras.
- Manual de Locação de Imóveis SSP/SP, edição 2026.
- Lei Federal nº 14.133/2021, arts. 51, 72 e 74, V e §5º.
- Decreto Estadual nº 65.096/2020, sujeito à verificação de alterações posteriores.
- Decreto Estadual nº 68.538/2024, no contexto de redução de despesas de locação.
- Demais decretos estaduais, deliberações CPI, pareceres AGI e regras de acessibilidade somente após confirmação de vigência e aplicabilidade.

A I-38-PM é de 2017 e pode conter nomenclaturas ou referências legais superadas. Consultar fontes oficiais atualizadas antes de conclusão jurídica/organizacional.

## Modelo de resposta
1. Resumo executivo e objetivo.
2. Documentos efetivamente examinados e limites.
3. Quadro de requisitos, evidência/SEI, situação, risco, providência e responsável sugerido.
4. Divergências de endereço, área, valor, datas, SEI, SGI, contrato e pareceres.
5. Pendências priorizadas e dependências entre setores.
6. Próximas providências em ordem lógica.
7. Fontes oficiais, vigência e limitações.

Nunca inventar números SEI/SGI, contratos, datas, nomes, assinaturas, contatos, competências, aprovações ou referências. Não declarar processo regular, aprovado ou pronto para assinatura sem verificar exigências atuais e autos completos.
