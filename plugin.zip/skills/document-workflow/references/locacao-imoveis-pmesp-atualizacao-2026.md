# Base especializada — Locação de imóveis PMESP / SSP-SP (atualização documental 2026)

## 1. Finalidade, fontes e limites

Usar junto com `locacao-imoveis-pmesp.md` em nova locação, renovação, prorrogação, revisão, reajuste, alteração de contrato, chamamento público/prospecção de mercado, contratação direta por inexigibilidade, instrução de expediente e análise de diligências da PMESP/SSP-SP.

Esta referência consolida o pacote fornecido pelo usuário, incluindo:
- Manual de Locação de Imóveis SSP/SP (2026), 37 páginas;
- Ofício nº 80/2026-SSP-SGC-DTP-CCP-PC;
- Despacho Diretora nº 1935/2026-DTP/SGC/SSP e Despacho SGC nº 36/2026-DTP/SGC/SSP;
- Parecer Referencial AGI nº 6/2026 e seus modelos/anexos;
- Orientações Consolidadas Sub-Cons PGE/SP, versão 1/2026;
- Resolução PGE nº 61, de 19/09/2025, alterada pela Resolução PGE nº 1, de 06/01/2026;
- Cota CJ/PM nº 88/2025;
- Deliberação CPI-8, de 04/12/2009, e cópia correlata;
- Lei Federal nº 14.133/2021;
- Decretos estaduais nº 41.043/1996, nº 10.947/2022, nº 67.452/2023, nº 68.017/2023, nº 68.158/2023 e nº 68.304/2024;
- IN SEGES/ME nº 103/2022;
- checklist atualizado em XLSX;
- modelos de edital de chamamento público, termo de referência, contrato e aditamento;
- Parecer CJ/PM nº 77/2026 sobre locador que é policial militar inativo.

O pacote contém cópias duplicadas e arquivos de trabalho. Não considerar a presença de cópias duplicadas como fontes independentes. O PDF “Fluxo - Locação de Imóveis” não forneceu texto extraível na análise; usar o Manual de 2026 e os documentos escritos, sem alegar leitura de conteúdo que não foi extraído. Um dos DOCX de aditamento não pôde ser aberto como arquivo Word válido; não inferir seu conteúdo.

**Controle de atualidade:** o Manual SSP/SP 2026 e o Ofício nº 80/2026 apresentam diretrizes institucionais de fluxo; o ofício afirma que todos os processos de nova locação, renovação, prorrogação, revisão e reajuste devem ser previamente encaminhados à Diretoria Técnico-Policial (DTP), independentemente do valor mensal. Ainda assim, antes de concluir sobre exigência vigente, confirmar publicação, alcance, alterações e instruções internas aplicáveis à PMESP e ao processo concreto. A Resolução PGE nº 61/2025 e sua alteração de 2026 devem ser lidas pelo texto consolidado. O Parecer Referencial AGI nº 6/2026 prevê utilização para casos que se enquadrem integralmente e indica prazo de um ano, mas verificar se houve atualização posterior.

Separar sempre:
1. conteúdo expresso da fonte;
2. norma cuja vigência e aplicabilidade foram verificadas;
3. inferência ou recomendação;
4. fato não verificável com os documentos disponíveis.

Não tratar checklist, manual ou parecer referencial como prova de que um requisito está cumprido no processo. Não declarar conformidade, regularidade, autorização ou prontidão para assinatura sem examinar as peças pertinentes.

## 2. Fluxo institucional SSP/SP de 2026

### 2.1 Alcance e encaminhamento à DTP
O Manual de Locação SSP/SP declara aplicação a processos de nova locação, renovação, prorrogação, revisão, reajuste e demais alterações contratuais relativas a imóveis utilizados pela SSP/SP, PMESP, PCSP e SPTC. O Ofício nº 80/2026-SSP-SGC-DTP-CCP-PC afirma que:
- a documentação deve ser previamente encaminhada à DTP, instruída com as peças pertinentes;
- a orientação alcança todos os processos de locação, independentemente do valor mensal;
- a dispensa de oitiva do Conselho do Patrimônio Imobiliário (CPI) para locações até R$ 10.000,00 não dispensa a análise institucional prévia da DTP;
- não se deve encaminhar diretamente à Coordenadoria de Patrimônio, à Secretaria de Gestão e Governo Digital ou a outras instâncias externas à Pasta sem manifestação prévia da DTP.
O Despacho Diretora nº 1935/2026 apresentou o Manual para apreciação; o Despacho SGC nº 36/2026 aprovou a proposta e a submeteu à apreciação do Secretário, sugerindo divulgação às instituições policiais. O Ofício nº 80/2026 é a comunicação institucional anexada no pacote. Ao descrever a cadeia de aprovação, distinguir o despacho de aprovação da proposta e o ofício de divulgação das competências legais de cada autoridade.

### 2.2 Os 20 passos do Manual SSP/SP 2026
Usar como roteiro sequencial e registrar a evidência de cada etapa:
1. Necessidade administrativa e finalidade pública;
2. Documento de Formalização da Demanda (DFD);
3. Verificação/certificação de imóvel público vago, disponível e adequado;
4. Documentação e caracterização do imóvel, incluindo peças adicionais para renovação/prorrogação;
5. Estudo Técnico Preliminar (ETP);
6. Termo de Referência (TR);
7. Análise/matriz de riscos;
8. Laudo/avaliação locatícia;
9. Identificação e documentação do locador;
10. Regularidade do locador e consultas a cadastros/sanções;
11. Justificativa da escolha do imóvel, preço e enquadramento em inexigibilidade, quando cabível;
12. Minuta de contrato conforme modelo aplicável;
13. Reserva/indicação orçamentária;
14. Parecer Referencial AGI vigente e declaração de enquadramento integral, se aplicáveis;
15. Anuência do Comitê Gestor do Gasto Público, quando exigida;
16. Conferência final da instrução;
17. Encaminhamento à DTP, após a conferência;
18. Manifestações institucionais, CPI conforme alçada e autorização da autoridade competente;
19. Formalização, assinaturas, publicidade e designação de gestores/fiscais;
20. Inserção/atualização do SGI, registros/averbações cabíveis e manutenção dos dados durante a vigência.

O Manual recomenda iniciar a instrução de nova locação, renovação ou prorrogação preferencialmente com antecedência mínima de 180 dias. Isso é orientação de planejamento; calcular com base na data real de término e no tempo de tramitação, sem tratar como prazo legal universal sem confirmação.

### 2.3 Conferência final e erros frequentes
Antes de encaminhar à DTP, conferir pelo menos:
- justificativa fundamentada, DFD, busca de imóvel público, ETP, TR e matriz de riscos;
- planta, matrícula/registro, IPTU, memorial descritivo e AVCB/CLCB, conforme aplicável;
- laudo válido e atual, compatibilidade de preço e ratificação quando cabível;
- documentos do locador, certidões e consultas de regularidade;
- justificativa de escolha e preço, fundamento da inexigibilidade e minuta padrão;
- reserva orçamentária, Parecer Referencial AGI e declaração, anuência do Comitê Gestor, deliberação CPI quando exigida e demais peças específicas.
Erros apontados pelo Manual: justificativa insuficiente; falta de prova de imóvel público indisponível; contradição entre justificativa, DFD, ETP e TR; fundamentação insuficiente da inexigibilidade; laudo desatualizado ou preço não justificado; documentos do imóvel/locador incompletos; certidões vencidas; minuta diferente do modelo vigente sem justificativa; falta de manifestação do Comitê Gestor ou declaração do parecer referencial; encaminhamento à DTP antes da conferência; renovação iniciada tardiamente; singularidade não demonstrada; valores divergentes entre laudo, reserva, ETP e contrato.

## 3. Inexigibilidade e chamamento público/prospecção de mercado

### 3.1 Regra de partida
A Lei nº 14.133/2021, arts. 51, 72 e 74, V e §5º, é a referência central. A regra geral de locação é licitar; a inexigibilidade é cabível quando as características de instalações e localização tornam necessária a escolha de imóvel certo e determinado. A instrução deve comprovar, entre outros elementos, avaliação prévia, inexistência de imóvel público vago e adequado, singularidade/necessidade da escolha e vantagem para a Administração.

### 3.2 Parecer Referencial AGI nº 6/2026 — orientação essencial
O Parecer Referencial AGI nº 6/2026 atualiza orientações anteriores e destina-se a casos semelhantes de locação pela Administração como locatária, sob a Resolução PGE nº 29/2015. Para utilizá-lo:
- juntar cópia integral do parecer ao processo individual;
- juntar declaração da autoridade competente confirmando que o caso concreto se enquadra integralmente nos pressupostos e orientações;
- não usar a via referencial se o caso não se subsumir integralmente; submeter dúvidas ou situações excepcionais à AGI/assessoria jurídica competente;
- confirmar se existe versão posterior antes de usar.

O parecer exige manifestação específica e fundamentada explicando por que se enquadra a inexigibilidade **com dispensa de chamamento público para prospecção de mercado**. Não basta declarar que o imóvel escolhido é conveniente. A Administração deve:
1. justificar, com base nas necessidades do ETP, por que o chamamento pode ser dispensado; ou
2. realizar chamamento público para prospecção nos termos da IN SEGES/ME nº 103/2022 (art. 20 ou arts. 10 a 19, conforme a hipótese) e analisar o resultado antes de decidir pela contratação direta.
Se a prospecção não demonstrar requisitos de inexigibilidade, reformular a instrução para licitação e submetê-la à análise jurídica pertinente. A IN é federal; o Parecer AGI recomenda sua observância no Estado nas omissões do Decreto nº 41.043/1996, com base no Decreto nº 67.608/2023, mas não generalizar sua aplicação sem examinar a hipótese.

### 3.3 Chamamento público
O pacote contém modelo de edital, TR e minuta de contrato para prospecção do mercado imobiliário e futura locação tradicional. Adaptar apenas depois de confirmar que o modelo é aplicável ao caso e às regras atuais. Em linhas gerais, o edital deve especificar:
- objeto, necessidade, fundamento e características mínimas do imóvel;
- localização, área, acessos, infraestrutura, leiaute, instalações, prazo para disponibilização e adaptações;
- forma, prazo e canal de apresentação das propostas;
- documentos da proposta, prova de titularidade, plantas e informações do imóvel;
- critérios objetivos de análise/seleção e aceitação;
- possibilidade de, se houver apenas um imóvel apto, examinar inexigibilidade; se houver vários imóveis aptos, avaliar a realização do certame;
- vistoria, entrega, fiscalização, conservação, benfeitorias, vigência, prorrogação, pagamento e anexos.
O modelo é de referência e contém campos em branco, menções genéricas e trechos que podem estar voltados a órgão federal (“União”, DOU, matrícula funcional etc.). Não o utilizar sem adaptação explícita para o Estado de São Paulo/PMESP, sem revisão jurídica e sem remover instruções alternativas incompatíveis. Conferir também se os critérios de habilitação e consultas foram atualizados.

### 3.4 Imóvel público disponível e compartilhamento
Priorizar imóvel próprio estadual vago e adequado, racionalizar a ocupação e examinar compartilhamento de espaço público quando a área estiver disponível e as atividades forem compatíveis (Deliberação CPI-8, art. 2º, e referências correlatas). O Parecer AGI associa isso também à política estadual de redução de despesas de locação prevista no Decreto nº 68.538/2024. A busca deve ser documentada e suficiente; não presumir que consulta a apenas um sistema/ente resolve toda a exigência. Quando o checklist ou parecer exigir manifestação de órgão técnico sobre inexistência de imóvel público, identificar qual órgão é competente para aquele processo e obter a certificação efetiva.

## 4. ETP, DFD, TR, riscos, preço e orçamento

### 4.1 DFD e ETP
O DFD deve anteceder o ETP e iniciar o planejamento. O Parecer AGI cita art. 72, I, da Lei nº 14.133/2021, art. 6º, I, do Decreto nº 68.304/2024 e Decreto nº 67.689/2023 para o Sistema de Planejamento e Gerenciamento de Contratações. O ETP deve caracterizar o interesse público e a melhor solução, considerar alternativas e mercado, demonstrar necessidade e adequação do imóvel, dimensionar área e infraestrutura e justificar a opção por locação. O Parecer AGI indica uso do Sistema ETP Digital no Portal de Compras do Governo Federal, nos termos de sua orientação; confirmar o procedimento vigente e eventual orientação interna da SSP/PMESP.

### 4.2 TR e análise de riscos
O TR deve ser coerente com DFD/ETP e especificar o objeto, necessidades físicas e operacionais, requisitos mínimos, critérios de seleção, prazos de disponibilização/adaptação, obrigações das partes, custos e condições de recebimento. O pacote aponta o Decreto estadual nº 68.185/2023 para TR e Decreto nº 68.158/2023 para gestão de riscos; o Parecer AGI também cita art. 72, I, da Lei nº 14.133/2021 e art. 6º, I, do Decreto nº 68.304/2024. Não deixar matriz de riscos genérica: vincular riscos a localização, adequação, acessibilidade, licenças, obras, disponibilidade, preço, prazo, condomínio/encargos e continuidade do serviço.

### 4.3 Avaliação e justificativa de preço
- Juntar laudo técnico prévio, atual e adequado à finalidade, acompanhado de fotos e fundamentação; deve comparar o preço pretendido com o mercado.
- O Parecer AGI nº 6/2026 afirma que o valor pretendido pelo locador não deve ser superior ao encontrado no laudo.
- A avaliação deve ser feita por engenheiro/arquiteto ou profissional habilitado segundo as regras aplicáveis e normas técnicas, incluindo ABNT NBR 14653. Estimativa informal de corretor não substitui laudo técnico.
- A Deliberação CPI-8, art. 4º, prefere o Método Comparativo de Dados de Mercado; se inviável por falta de comparativos, o Método da Renda deve ser justificado. A Deliberação prevê avaliação simplificada até R$ 5.000 mensais, observadas as normas ABNT, e laudo fotográfico. Confirmar atualização normativa antes de aplicar limites e métodos.
- Comparar área, endereço, estado de conservação, data do laudo, preço, ETP, proposta, TR, nota de reserva e minuta. Divergências devem ser explicadas, não presumidas como erro inofensivo.
- Estimativa de despesa e compatibilidade orçamentária são itens distintos: a reserva deve cobrir valor e período da contratação conforme regras orçamentárias. “Em acompanhamento” ou previsão genérica não equivale a reserva/manifestação formal.

### 4.4 Acessibilidade, zoneamento e condição do imóvel
O Parecer AGI recomenda verificar junto ao Município, se possível, declaração de compatibilidade do uso pretendido com o zoneamento. Também exige consideração de acessibilidade (Lei federal nº 7.853/1989 e Lei estadual nº 12.907/2008, conforme parecer), com identificação de adequações e responsabilidade do locador conforme a minuta-padrão citada. Descrever condição real: integralmente acessível, parcialmente acessível, não comprovado ou pendente; registrar laudo/manifestação técnica, adaptações, custo, prazo, responsável e impacto operacional. Não confundir AVCB/CLCB com acessibilidade nem com aprovação de projeto.

## 5. Documentação do imóvel e do locador

### 5.1 Imóvel
Conforme o caso e o checklist atualizado, conferir:
- planta e caracterização completa;
- matrícula/transcrição atualizada, com filiação vintenária e certidão de ônus quando exigidas;
- carnê/IPTU do último exercício e prova de quitação, quando exigidos;
- memorial descritivo do estado do imóvel, com atenção a instalações elétricas/hidráulicas e defeitos;
- certidão/cadastro imobiliário municipal e certidão de débitos imobiliários;
- manifestação/certificação de inexistência de imóvel público vago e adequado;
- compatibilidade do uso com zoneamento, quando obtida/exigida;
- AVCB/CLCB ou documento aplicável de segurança contra incêndio;
- contrato vigente e comprovantes de pagamento em renovação/prorrogação, conforme o caso;
- relatório de vistoria, fotografias e documentos de áreas/adaptações quando necessários.
Conferir se endereço, área, descrição e titularidade coincidem entre matrícula, IPTU/cadastro municipal, planta, laudo, memorial, contrato e SGI. Peças históricas ou desatualizadas devem ser sinalizadas.

### 5.2 Locador — pessoa física
O Parecer Referencial AGI nº 6/2026 e o checklist atualizado indicam, conforme aplicabilidade:
- RG/CPF e prova de identidade/representação;
- manifestação de concordância com preço e dados bancários, se o modelo institucional exigir;
- declaração sobre não ser funcionário público estadual, quando exigida pela regra citada (art. 243 da Lei estadual nº 10.261/1968); não confundir automaticamente militar inativo com servidor da ativa;
- certidões de regularidade fiscal federal e municipal/estadual conforme incidência e texto normativo vigente;
- CRF/FGTS, CNDT e consultas CADIN estadual, sanções administrativas, CNIA/CNCIAI e relação de apenados do TCE-SP, conforme o parecer e aplicabilidade;
- declaração de inexistência de fato impeditivo;
- certidão de insolvência civil quando exigível para pessoa física ou sociedade simples.
Conferir validade das certidões no momento relevante e verificar o texto consolidado da Resolução PGE nº 61/2025, alterada pela Resolução nº 1/2026, que alterou a referência à regularidade com Fazendas estadual/distrital e municipal/distrital relativamente aos tributos incidentes sobre o objeto. Não copiar lista antiga sem reconciliação.

### 5.3 Locador — pessoa jurídica
Conforme o Parecer AGI nº 6/2026 e a situação:
- CNPJ e atos constitutivos atualizados;
- documentos que comprovem poderes dos administradores/representantes;
- regularidade fiscal pertinente;
- CRF/FGTS e CNDT;
- consultas CADIN estadual, sanções administrativas, CNIA/CNCIAI, TCE-SP e CEIS, conforme aplicabilidade e fonte vigente;
- declaração de inexistência de fato impeditivo;
- certidão de falência quando se tratar de empresário individual/sociedade empresária, nos termos aplicáveis;
- outros documentos de habilitação/representação que o caso exigir.
A lista exata varia conforme natureza do locador, objeto, regra aplicável e texto consolidado do parecer. Não exigir mecanicamente todos os documentos de todas as categorias sem justificar, nem deixar de cumprir item expressamente aplicável.

### 5.4 Conferência de regularidade
A Resolução PGE nº 61/2025 trata da dispensa de análise jurídica nas hipóteses delimitadas de prorrogação de contratos de locação sob o art. 74, V e §5º, da Lei nº 14.133/2021. O art. 2º lista documentos para o expediente; os documentos vencidos devem ser atualizados na ocasião do aditamento. A Resolução PGE nº 1/2026 alterou o inciso XI do art. 2º para exigir prova de regularidade com Fazendas estadual/distrital e municipal/distrital quanto aos tributos incidentes em relação ao objeto. A lista e as exceções precisam ser conferidas no texto consolidado, não em cópia pré-alteração.

## 6. Parecer Referencial AGI nº 6/2026 — uso e cautelas

### 6.1 Requisitos processuais
O parecer propõe uso em casos que se subsumam integralmente às orientações, com:
- cópia integral do parecer no processo;
- declaração da autoridade competente confirmando enquadramento integral;
- documentos e manifestações que provem o atendimento de cada pressuposto;
- encaminhamento de dúvida de alcance ou situação não integralmente enquadrada à AGI/assessoria jurídica competente.

O parecer aborda nova locação por inexigibilidade e condições de instrução. Não basta anexá-lo; é necessária a declaração e o atendimento real de todas as condições aplicáveis. Parecer referencial não é aprovação individual automática.

### 6.2 Publicidade e formalização
O Parecer AGI nº 6/2026 recomenda observar:
- assinatura/formalização do contrato via SEI/SP, nos termos do Decreto nº 67.641/2023;
- divulgação do ato de autorização da contratação direta ou extrato em sítio eletrônico oficial, nos termos do art. 72, parágrafo único, da Lei nº 14.133/2021;
- divulgação do contrato no PNCP como condição de eficácia (art. 94);
- publicação resumida do ato no DOE, conforme recomendação constante do parecer e regras citadas;
- registro do contrato na matrícula do imóvel, para resguardar sua vigência na hipótese de alienação, conforme art. 167, I, item 3, da Lei nº 6.015/1973 e art. 8º da Lei nº 8.245/1991;
- conferência de gravames na matrícula.
Confirmar como esses pontos se aplicam ao instrumento, ao sistema e à orientação atual.

### 6.3 Renovação de contratos sob Lei nº 8.666/1993
O Parecer AGI nº 6/2026, com base nas Orientações Consolidadas Sub-Cons PGE/SP versão 1/2026 e na disciplina estadual de transição (Decreto nº 67.885/2023, segundo o parecer), recomenda que, ao término de contrato de locação ainda regido pela Lei nº 8.666/1993, seja celebrada nova contratação sob a Lei nº 14.133/2021, evitando nova prorrogação. O parecer distingue a recomendação de transição da validade de prorrogações já realizadas. Se ultrapassado o vencimento sem nova contratação, o parecer menciona prorrogação automática em determinadas condições e exige justificar por que não foi possível concluir a nova contratação e quais medidas estão em curso. Não aplicar automaticamente essa conclusão a qualquer contrato: identificar o regime original, cláusula, histórico de aditamentos, datas e orientação jurídica vigente.

## 7. Resolução PGE nº 61/2025 e Resolução nº 1/2026 — dispensa de parecer na prorrogação

A Resolução nº 61/2025 dispensa manifestação das Consultorias Jurídicas em processos de **prorrogação** de contratos de locação celebrados com fundamento no art. 74, V e §5º, da Lei nº 14.133/2021, desde que integralmente cumpridas as condições. Não estender a dispensa a nova locação, reajuste isolado, revisão, facilities, built to suit ou alterações contratuais que extrapolem o objeto permitido sem conferir a norma.
Exceções expressas da Resolução:
- locação com serviços para operação/manutenção (facilities);
- locação sob medida (built to suit);
- falta de manifestação prévia do CPI quando cabível;
- aditamento com outras modificações além da prorrogação;
- alteração da minuta padronizada fora das instruções permitidas.
Nos casos de exceção, o processo deve ser encaminhado para análise jurídica conforme a resolução e orientação atual.

O processo de prorrogação, segundo o texto disponibilizado, deve conter:
- manifestação fundamentada do dirigente da UGE;
- matrícula/transcrição atualizada;
- IPTU do último exercício com prova de quitação;
- memorial descritivo do estado do imóvel, incluindo defeitos;
- indicação de recursos orçamentários;
- informação técnica de inexistência de imóvel público vago adequado;
- consultas aos cadastros e sanções listados no art. 2º;
- certidões de regularidade fiscal federal, estadual/municipal pertinente, FGTS e trabalhista conforme aplicabilidade;
- insolvência civil para pessoa física/sociedade simples ou falência para empresário individual/sociedade empresária, conforme o caso.
Certidões vencidas devem ser atualizadas por ocasião do aditamento.

A autoridade competente deve justificar e autorizar por escrito, atestando, no mínimo:
1. contrato ainda vigente;
2. aluguel atualizado compatível com o mercado;
3. reajustes conforme Decreto nº 41.043/1996 e deliberações do CPI;
4. uso da minuta de termo de prorrogação pré-aprovada pela PGE sem alterações incompatíveis;
5. manutenção da situação fática que ensejou a inexigibilidade (art. 74, V e §5º).
A declaração deve seguir o modelo do Anexo II da Resolução. Após assinatura, providenciar publicação do extrato no DOE e no PNCP conforme art. 5º e regras vigentes. Ausência de oposição do locador não dispensa formalizar o aditamento.

## 8. CPI-8, alçadas e avaliação

A Deliberação CPI-8, de 04/12/2009, é citada no Manual e no Parecer AGI. O texto fornecido indica:
- preferência por imóvel próprio, racionalização do espaço, compartilhamento quando houver espaço disponível e compatibilidade, e localização em área de custo locativo compatível;
- para valores mensais: até R$ 10.000,00, dispensada oitiva do CPI; de R$ 10.000,01 a R$ 20.000,00, manifestação prévia da instância técnica/Secretaria Técnica e Executiva; de R$ 20.000,01 a R$ 50.000,00, manifestação prévia do Presidente; acima de R$ 50.000,00, manifestação prévia do colegiado;
- locações de unidades autônomas no mesmo imóvel por um mesmo órgão/entidade contam como locação única para alçada;
- laudos preferencialmente por método comparativo de dados de mercado, com fotos; método da renda se não houver comparativos e houver justificativa; avaliação simplificada prevista para aluguel mensal até R$ 5.000,00, observadas normas ABNT;
- avaliação por engenheiro/arquiteto de órgão técnico ou terceiro contratado conforme a lei.
O Manual 2026 apresenta a instância técnica com nomenclatura “Coordenadoria de Controle Técnico Processual” na faixa R$ 10.000,01–R$ 20.000,00. Conferir nomenclatura atual e redação consolidada. A dispensa de oitiva CPI até R$ 10.000 não dispensa o encaminhamento prévio à DTP segundo o Ofício nº 80/2026.
Não somar ou fracionar artificialmente contratos para contornar alçada; observar a regra de locações no mesmo imóvel.

## 9. Comitê Gestor do Gasto Público
O Parecer AGI nº 6/2026 cita anuência do Comitê Gestor do Gasto Público conforme art. 2º, IX, “c”, do Decreto nº 64.065/2019, com redação do Decreto nº 67.452/2023. O Manual SSP/SP também reserva etapa própria para a manifestação prévia em hipóteses exigidas, antes das etapas subsequentes. Confirmar hipóteses e alçada vigentes; não confundir anuência do Comitê Gestor com manifestação do CPI, autorização do Secretário ou parecer jurídico. Não afirmar que existe anuência sem documento completo e identificável.

## 10. Modelo de contrato e modelos de chamamento: adaptações necessárias

O pacote contém modelos federais ou genéricos elaborados sob Lei nº 14.133/2021:
- Edital de chamamento público para prospecção;
- Termo de Referência para chamamento;
- Termo de contrato para locação tradicional;
- Termo de aditamento.
Antes de reutilizar:
- identificar se o modelo é estadual, federal ou genérico; os modelos de chamamento e contrato usam campos e referências à União, DOU, autarquia/fundação federal, processo e matrícula funcional, além de referências à IN SEGES/ME nº 103/2022;
- adaptar órgão, locatário, CNPJ, autoridades, processo SEI, fundamento legal, publicidade, sistemas, instâncias de aprovação, foro e modelos de assinatura para Estado de São Paulo/PMESP;
- conferir se a minuta de contrato está conforme o anexo do Parecer Referencial AGI nº 6/2026 vigente, e não substituir a minuta estadual por modelo genérico sem justificativa e análise;
- revisar cláusulas de objeto, destinação, prazo, reajuste, encargos, conservação, obras/adaptações, acessibilidade, vistoria, garantias, pagamento, rescisão, entrega/devolução, publicidade, fiscalização e registro;
- eliminar alternativas de redação incompatíveis e campos “XXXXX”, “xx/xx/20xx”, notas explicativas e opções não escolhidas;
- para aditamento, confirmar regime legal do contrato original, minuta pré-aprovada aplicável e limites da Resolução PGE nº 61/2025; alteração de locador/titularidade não é simples prorrogação e pode exigir análise jurídica específica.
O documento “Termo de aditamento locação de imóvel..docx” parece modelo genérico federal e contém referências a União/Lei nº 14.133/2021; o outro arquivo com nome parecido não abriu como DOCX válido. Não tratar nenhum deles como minuta institucional da PMESP sem validação.

## 11. Parecer CJ/PM nº 77/2026 — locador que é PM inativo
O parecer analisou situação concreta de locação em Conchal/SP após falecimento dos locadores originais, sub-rogação a herdeiros, copropriedade e procuração a herdeiro residente no exterior. A ementa aponta inexistência de óbice legal no caso examinado para policial militar **inativo** figurar como locador/representante e beneficiário do aluguel, distinguindo a vedação estatutária citada (art. 243 da Lei estadual nº 10.261/1968) e a condição de servidor da ativa. 
Limites:
- é parecer consultivo sobre fatos específicos, não autorização automática para qualquer contrato com agente público;
- verificar status funcional, titularidade, sucessão, procurações, beneficiários e documentos atuais;
- examinar conflito de interesses e impedimentos à luz da Lei nº 14.133/2021 e normas estatutárias vigentes;
- não transportar nomes, endereço, número de processo ou conclusões fora do caso sem verificar analogia e alcance;
- dúvida sobre alcance deve ser encaminhada à CJ/PM ou órgão jurídico competente.
O checklist atualizado inclui declaração de que proprietário pessoa física não é funcionário público estadual; não aplicar isso mecanicamente sem conciliar com o Parecer CJ/PM nº 77/2026 e com a distinção entre ativo/inativo, consultando a assessoria jurídica se o caso envolver servidor/inativo.

## 12. Como usar o checklist XLSX recebido

O arquivo “CHECKLIST ATUALIZADO.xlsx” traz lista de verificação com colunas S/N, folhas e observações. Seções:
1. manifestação fundamentada do dirigente da unidade de despesa;
2. avaliação do imóvel;
3. documentação do imóvel;
4. documentação do proprietário, separada entre pessoa física e jurídica;
5. outras formalidades;
6. documentos do art. 72 da Lei nº 14.133/2021.
Os itens de manifestação fundamentada incluem inexistência de imóvel próprio estadual adequado; adequação, infraestrutura e área; motivos de preferência com comparação de áreas, endereços e valores de alternativas; adequação da construção, vagas, área e funcionários/equipamentos; impossibilidade de compartilhamento; singularidade e vantagem; justificativa específica para dispensar chamamento; declaração de enquadramento no Parecer AGI nº 6/2026 quando integralmente aplicável.
O checklist inclui laudo fotográfico, matrícula/transcrição, IPTU, memorial, informação técnica sobre imóveis públicos, certidões, AVCB, cadastro municipal, zoneamento, contrato/comprovantes para renovação, documentação de titular/representante, regularidade fiscal, FGTS, CNDT, consultas a sanções e cadastros, minuta-padrão, recursos orçamentários, CPI, Comitê Gestor, pesquisa de imóveis, DFD, ETP, riscos, TR, estimativa de despesa e autorização.
**Advertência:** o XLSX contém referências históricas e itens que podem ser desatualizados, redundantes ou dependentes da hipótese (p.ex., referências a Resoluções PGE antigas, CECI/SECI, listas de consultas, IN federal, “Certidão do Tribunal de Justiça” e referências a órgãos com nomenclatura antiga). Usar como checklist de rastreamento, não como norma autônoma. Reconciliar cada item com o Manual SSP/SP 2026, Parecer AGI nº 6/2026, Resolução PGE consolidada, Lei nº 14.133/2021 e atos estaduais vigentes.

## 13. Fontes normativas e notas de leitura
- Lei Federal nº 14.133/2021: arts. 44, 51, 72, 73, 74, V e §5º, 91, 94.
- Decreto Estadual nº 41.043/1996, redação atualizada: instrução, locação e alçadas; conferir alterações.
- Decreto Estadual nº 67.608/2023: referência indicada no Parecer AGI para observância de normas complementares.
- Decreto Estadual nº 67.641/2023: formalização por SEI/SP, conforme Parecer AGI.
- Decreto Estadual nº 67.689/2023: planejamento/DFD, conforme Parecer AGI.
- Decreto Estadual nº 67.885/2023: transição entre regimes, conforme Parecer AGI.
- Decreto Estadual nº 68.017/2023: ETP.
- Decreto Estadual nº 68.158/2023: gestão de riscos.
- Decreto Estadual nº 68.185/2023: TR.
- Decreto Estadual nº 68.304/2024: contratação direta por inexigibilidade/dispensa.
- Decreto Estadual nº 68.538/2024: redução de despesas de locação e preferência por imóvel estadual adequado.
- Decreto Estadual nº 64.065/2019 e nº 67.452/2023: Comitê Gestor.
- Deliberação CPI-8, de 04/12/2009, e Deliberação CPI-4, de 14/10/2002.
- IN SEGES/ME nº 103/2022, nos limites indicados pela legislação estadual e pelo Parecer AGI.
- Parecer Referencial AGI nº 6/2026.
- Resolução PGE nº 61/2025, alterada pela Resolução PGE nº 1/2026.
- Orientações Consolidadas Sub-Cons PGE/SP, versão 1/2026.
- Parecer CJ/PM nº 77/2026, caso específico sobre PM inativo locador.
- Manual SSP/SP 2026, Ofício nº 80/2026 e despachos de aprovação/encaminhamento.
- Modelos genéricos de edital, TR, contrato e aditamento e checklist XLSX do pacote.

## 14. Padrão de resposta para análise de locação
Estruturar:
1. resumo executivo e objeto (nova locação, renovação, prorrogação, revisão, reajuste ou aditamento);
2. regime legal do contrato e cronologia;
3. lista dos documentos realmente examinados;
4. quadro de requisitos: requisito/fundamento, evidência e ID/link SEI, validade, situação, risco, providência, responsável sugerido e dependência;
5. divergências de imóvel, titularidade, área, valor, datas, prazo, reajuste, certidões, minuta, regime legal e sistemas;
6. decisões que dependem de DTP, CPI, Comitê Gestor, autoridade competente, órgão técnico ou jurídico;
7. pendências priorizadas e sequência lógica;
8. fontes e limitações de vigência/extração.

Usar os estados: **Comprovado no documento examinado**, **Relatado, mas não verificado**, **Pendente**, **Parcialmente atendido**, **Não verificável**, **Não aplicável (justificar)**.

Nunca inventar número SEI/SGI, contrato, data, valor, titular, certidão, laudo, autorização ou manifestação. Não tratar ausência de menção em ofício como prova de ausência no SEI. Não reutilizar dados dos exemplos do pacote em outro caso. Para documento escaneado, registrar se a extração foi incompleta e conferir a imagem. Para dúvida jurídica ou fora dos pressupostos do parecer referencial, encaminhar ao setor jurídico competente.
