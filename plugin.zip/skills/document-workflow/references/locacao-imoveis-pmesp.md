# Base especializada: locação de imóveis para PMESP / SSP-SP

## Uso e limites
Aplicar esta referência quando o usuário solicitar análise, instrução, saneamento, revisão ou elaboração de documentos de locação de imóveis da Polícia Militar do Estado de São Paulo (PMESP) ou da Secretaria da Segurança Pública (SSP/SP). É uma base de trabalho, não substitui consulta à versão vigente das normas, ao processo SEI completo, aos pareceres jurídicos aplicáveis nem à autoridade competente.

Separar sempre: (1) conteúdo expresso dos documentos; (2) exigências normativas confirmadas; (3) inferências/recomendações; (4) itens não verificáveis por falta de documentos. Nunca presumir que documento mencionado está juntado, válido ou aprovado. A ausência de referência num ofício não prova ausência no processo completo.

## Fontes de referência já examinadas no contexto de trabalho
- Manual de Locação de Imóveis SSP/SP, edição 2026, 37 páginas: roteiro em 20 passos, páginas 7–30; erros frequentes, página 32; referências normativas, página 5. Consultar o PDF e confirmar a versão vigente antes de afirmar conteúdo exato.
- I-38-PM, Instruções para Administração de Bens Imóveis, 2ª edição (2017), capítulo V, arts. 83–93, especialmente art. 84, §3º, e art. 86. É referência institucional histórica e deve ser interpretada em conjunto com a legislação posterior e atos atuais.
- Lei Federal nº 14.133/2021, especialmente arts. 51, 72 e 74, V e §5º.
- Decreto Estadual nº 41.043/1996 e alterações; Decreto nº 43.321/1998 (memorial descritivo); Decreto nº 68.017/2023 (ETP); Decreto nº 68.185/2023 (TR); Decreto nº 68.304/2024 (contratação direta); Decreto nº 64.065/2019 e alterações (Comitê Gestor); Decreto nº 68.538/2024 (redução de despesas de locação); Deliberações CPI-4/2002 e CPI-8/2009; Parecer Referencial AGI vigente e aplicável.
- IN SEGES/ME nº 103/2022: norma federal, cujo uso no processo estadual deve ser justificado conforme orientações jurídicas estaduais; não presumir aplicação automática à PMESP.
- Lei Estadual nº 12.907/2008 e legislação aplicável à acessibilidade.

Sempre verificar vigência, alterações e aplicabilidade no caso concreto em fontes oficiais antes de produzir conclusão jurídica. Não copiar referências de modelos antigos sem validação.

## Roteiro de 20 passos do Manual SSP/SP (2026)
Usar como checklist, verificando cada item no processo: (1) justificar necessidade/finalidade; (2) DFD; (3) verificar imóvel público disponível e adequado; (4) documentação e caracterização do imóvel; (5) ETP; (6) Termo de Referência; (7) análise/matriz de riscos; (8) avaliação locatícia; (9) documentação do locador; (10) regularidade do locador e consultas aplicáveis; (11) justificar inexigibilidade; (12) minuta contratual; (13) recursos/reserva orçamentária; (14) parecer referencial e declaração de enquadramento, se aplicável; (15) manifestação/anuência do Comitê Gestor, quando exigida; (16) conferência final; (17) encaminhamento à DTP no fluxo aplicável; (18) manifestações institucionais e autorizações necessárias; (19) formalização do contrato; (20) registro/atualização do SGI.

Para cada passo, classificar como: **Comprovado no documento examinado**, **Relatado, mas não verificado**, **Pendente**, **Parcialmente atendido**, **Não verificável** ou **Não aplicável (justificar)**. Não usar “cumprido” apenas porque um ofício declara a providência; conferir o documento comprobatório quando disponível.

## Requisitos e pontos de controle
- Inexistência de imóvel público: comprovar a busca por imóvel público vago e adequado; documentar consultas estaduais e municipais conforme exigências do caso. Avaliar compartilhamento de espaço quando aplicável. Não limitar o requisito à consulta a um único ente.
- Pesquisa imobiliária: a I-38-PM, art. 84, §3º, prevê pesquisa na região em pelo menos três imobiliárias quando não houver imóvel próprio estadual disponível, identificando alternativas, áreas, endereços corretos, valores e fontes; registrar assinatura/data do responsável e justificar a escolha. Conferir também a orientação jurídica aplicável ao caso sobre chamamento público/prospecção.
- ETP: demonstrar necessidade, solução pretendida, adequação ao interesse público, levantamento de mercado e por que alternativas não atendem. Manter coerência com DFD, TR, avaliação, proposta, orçamento e minuta.
- Inexigibilidade: Lei 14.133/2021, art. 74, V e §5º: verificar avaliação prévia; certificação de inexistência de imóvel público vago e adequado; singularidade do imóvel e justificativa de vantagem. Preço abaixo do laudo, isoladamente, não prova todos os requisitos.
- Avaliação locatícia: verificar imóvel, área, condições, data/validade e escopo; conciliar o valor com ETP, proposta do locador, reserva orçamentária e minuta. Explicitar cálculos e custos adicionais quando disponíveis.
- Imóvel/locador: conferir título/matrícula, planta baixa, cadastro municipal, memorial descritivo, IPTU do último exercício quitado/atualizado e demais certidões requeridas. CRF/FGTS e certidões dependem das exigências jurídicas e da natureza do locador. Conferir validade na data relevante.
- Acessibilidade: não basta citar certidão. Descrever atendimento integral/parcial, requisitos pendentes, adaptações, custos, responsáveis, prazos e efeito sobre o uso público/operacional; exigir manifestação técnica adequada.
- Minuta: usar a minuta-padrão indicada no parecer referencial vigente. Remover/identificar duplicidades, registrar alterações e submetê-las à análise jurídica quando exigido. Conferir endereço, proprietário, valor, prazo, reajuste, encargos, adaptações e obrigações.
- Orçamento: obter manifestação formal do setor competente sobre recursos suficientes; “em acompanhamento” não equivale a comprovação de disponibilidade.
- Governança: distinguir manifestação do Conselho do Patrimônio Imobiliário da anuência do Comitê Gestor. Verificar valor locatício, alçadas, atos vigentes e tramitação aplicável; não afirmar que a anuência existe sem documento.
- Finalização: certidões atualizadas, retirar duplicidades conforme orientação, incluir no ofício de encaminhamento lista de documentos e links SEI, conferir todos os dados e só então tratar de formalização/registro/atualização do SGI.
- Planejamento: o Manual SSP/SP 2026 recomenda iniciar novas contratações, renovações ou prorrogações preferencialmente com antecedência mínima de 180 dias; confirmar data de término do contrato antes de avaliar cumprimento.

## Modelo de análise
1. Resumo executivo.
2. Escopo e documentos efetivamente examinados.
3. Quadro de requisitos (requisito, evidência/SEI, situação, risco, providência, responsável sugerido).
4. Inconsistências entre ofícios e documentos (nomes, endereços, áreas, valores, datas, códigos SEI, versões de minuta, pareceres).
5. Pendências priorizadas por risco e dependências.
6. Próximas ações ordenadas para evitar retrabalho.
7. Fontes oficiais, vigência e limitações.

## Exemplo de referência operacional — caso 52º BPM/I (Mirassol)
Processo SEI 057.00088808/2026-84; imóvel informado na Avenida Victorio/Vitorio Baccan, nº 2485, Mirassol/SP; SGI nº 26498. CPI-5 informou proposta de R$ 13.000/mês e laudo PGE de R$ 13.700/mês, Parecer AGI nº 352/2026, acessibilidade parcial e providências para Conselho do Patrimônio Imobiliário/Comitê Gestor. Ofício DF-428/31/2026 apontou CRF/FGTS, acessibilidade, orçamento, pesquisa imobiliária formalizada, duplicidade de minuta, IPTU, prova de inexistência de imóvel público, saneamento do ETP, manifestação fundamentada do dirigente, autorização, justificativa de compartilhamento e declaração de enquadramento no Parecer Referencial AGI nº 6/2026, se aplicável; também solicitou certidões atualizadas, retirada de duplicidades e links SEI no ofício de encaminhamento.

Tratar estes dados como exemplo histórico de aplicação, não como modelo universal nem como prova de que as pendências continuam atuais. Não reutilizar endereço, valores, nomes, códigos SEI ou conclusões em outros casos. No caso concreto, o CPI-5 e a DF não são necessariamente contraditórios: o CPI-5 relata providências e pede apoio para tramitação externa; a DF identifica requisitos adicionais que entende necessários para saneamento. O parecer favorável condicionado não prova atendimento de todas as condições.

## Cuidados jurídicos e documentais
- Não declarar que a contratação é legal/ilegal, pronta para assinatura ou aprovada sem verificar o processo completo e as exigências vigentes.
- Distinguir parecer específico de parecer referencial; não presumir que são o mesmo documento.
- Não afirmar que documento inexiste no SEI apenas porque não aparece no ofício.
- Não inventar número de processo, código SEI, data, assinatura, matrícula, valor ou referência normativa.
- Citar a fonte imediatamente após as afirmações relevantes; usar fontes oficiais e atualizadas. Se não houver acesso à fonte integral, declarar a limitação.
- A análise é apoio documental e não substitui manifestação jurídica ou técnica competente.
