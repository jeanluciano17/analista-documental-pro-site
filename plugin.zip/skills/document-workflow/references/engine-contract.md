# Document engine integration contract

This is a design contract for the separate `document_engine` MCP service. It does not itself deploy or connect that service.

## Planned tools

- `inspect_document(filename, content_base64)`: accepts DOCX/PDF/TXT/MD bytes as base64; returns extracted text, character/word counts, DOCX table data, basic metadata, and warnings. Scanned-PDF OCR is not implemented.
- `compare_documents(old_filename, old_content_base64, new_filename, new_content_base64)`: returns line-level changes, counts, and unified diff. It is a text comparison, not legal interpretation.
- `create_document(title, content, formats)`: creates DOCX and/or PDF from text or structured blocks and returns base64 file bytes, MIME types, byte sizes, and SHA-256 hashes. The DOCX and PDF are generated separately; exact visual parity is not guaranteed.

## Implemented input safeguards in the starter

- 12 MiB default cap per uploaded file, with supported-extension and base64 validation.
- DOCX ZIP validation, entry-count and uncompressed-size caps, and compression-ratio checks.
- Encrypted PDFs rejected; PDF page count capped at 500.
- Generated content capped at 1,000,000 characters and 5,000 blocks; title capped at 300 characters.
- These are preliminary controls, not a substitute for authentication, malware scanning, sandboxing, or a security review.

## Connection and security requirements

Before ChatGPT can use these tools, deploy the server to an HTTPS endpoint that supports MCP Streamable HTTP and connect it through a supported integration workflow. Do not add a placeholder or invented endpoint to `mcp.json`. Configure authentication, rate limits, safe logging, monitoring, and a retention policy at the gateway/platform before production use. The starter itself has no user authentication layer and must not be exposed publicly without a secured gateway.

## Verification checklist

1. Confirm the live endpoint, authentication, TLS, and rate limiting.
2. Verify the plugin exposes all three tools.
3. Run automated tests in an environment with dependencies installed.
4. Test DOCX and text extraction, PDF extraction, and rejection of oversized/unsupported files and suspicious DOCX packages.
5. Compare two known versions and check additions/removals.
6. Generate DOCX/PDF, decode artifacts, open both, and verify content/layout.
7. Verify failure messages and that document contents are not written to logs.
8. Test OCR separately only after an OCR component is added.
