# Base especializada — Regularização de ocupação imobiliária da PMESP

## 1. Finalidade, escopo e limites
Esta referência consolida os arquivos fornecidos pelo usuário: Guias Práticos de Doação, Cessão de Uso, Transferência de Administração e Comodato; respectivos checklists, modelos e exemplos; I-38-PM, 2ª edição; Guia de Orientação da Gestão do Patrimônio Imobiliário do Estado (2014); Nota Técnica AGI nº 2/2020; Notas Técnicas CJ/SSP nº 119/2019 e nº 618/2019; Ofício GPG-Cons. Circular nº 2.896/2002; OS Subcmt PM-048/17; NI PM4-002/2.1/19; OS PM4-002/2.1/19 e OS PM4-001/2.1/19, de 08FEV19, relativa ao SGI.

Os guias e checklists são referências institucionais de trabalho e podem refletir legislação, órgãos, sistemas, contatos ou procedimentos de sua época. Antes de concluir sobre obrigação jurídica atual, confirmar texto integral, vigência, alterações, alçadas e orientações atuais da PGE/SSP/PMESP. Não tratar este resumo como parecer jurídico nem como substituto dos autos SEI completos.

Sempre separar: (a) o que consta literalmente na fonte; (b) requisito cuja vigência/aplicabilidade foi confirmada; (c) recomendação de instrução; (d) ponto não verificável. Não afirmar que um documento está ausente do processo porque não foi citado em ofício, nem que está válido/aprovado porque foi mencionado.

## 2. Escolha do instrumento jurídico: árvore inicial
A primeira triagem dos Guias Práticos é identificar **quem é o proprietário** e **como pretende disponibilizar o imóvel**:

- **Doação:** proprietário pessoa física, pessoa jurídica ou município pretende transferir a propriedade do imóvel à Fazenda do Estado para uso da PMESP. Exige análise da capacidade do doador, titularidade, autorização/competência para alienar, interesse público, avaliação, formalização e registro.
- **Cessão de uso:** o imóvel é de ente público (nos guias: União, Município ou autarquia) e o titular/administrador pretende permitir seu uso pela Fazenda Estadual/PMESP, sem transferir a propriedade. Confirmar a espécie jurídica correta, competência do ente, prazo, encargos e condições.
- **Transferência de administração:** imóvel sob administração de outro órgão público estadual, em regra da Administração Direta, com proposta de transferir a administração/uso de todo ou parte do imóvel à PMESP. O guia descreve como procedimento administrativo interno, distinto de doação/cessão contratual; pode exigir manifestação do órgão detentor e tramitação superior. O próprio guia alerta que pode haver casos de imóveis não pertencentes à Fazenda Estadual, mas sob posse de órgão da Administração Direta: verificar o caso concreto.
- **Comodato:** empréstimo gratuito de imóvel de pessoa física ou pessoa jurídica de direito privado à Fazenda Estadual. O guia enquadra o comodato nos arts. 579 a 585 do Código Civil e cita o Ofício GPG-Cons. Circular nº 2.896/2002 e a NT CJ/SSP nº 618/2019 como referências para aplicar ao comodato as regras indicadas para cessão de uso em que a Fazenda é cessionária. Confirmar orientação jurídica atual.
- **Permissão/autorização de uso:** não confundir com comodato nem com cessão; a NT AGI nº 2/2020 trata das figuras de outorga de uso. Identificar natureza do bem, ente proprietário, precariedade, prazo, finalidade e ato competente, submetendo a enquadramento jurídico quando houver dúvida.

A modalidade não deve ser escolhida apenas pelo nome dado pelo proponente. Conferir matrícula/título, titularidade real, natureza jurídica do proprietário, intenção formal, existência de ocupação anterior, encargos, prazo e ato que autoriza o uso.

## 3. Regra transversal: regularização antes de investimentos
A apresentação dos Guias afirma que as I-38-PM buscam padronizar a administração e o controle dos imóveis e que o regramento não permite empenho de recursos orçamentários para construções e reformas de 2º ou 3º escalão em imóveis cuja ocupação não esteja regularizada. A justificativa é evitar investimento significativo em imóvel sem propriedade estadual ou sem instrumento jurídico que assegure a posse por tempo mínimo. Confirmar a regra exata e sua aplicabilidade na versão vigente da I-38-PM e nas normas técnicas/orçamentárias atuais antes de aplicá-la a um caso.

Antes de aceitar imóvel novo, verificar a OS Subcmt PM-048/17 (05DEZ17), que suspendeu temporariamente a tramitação de expedientes de recebimento pela Fazenda de imóveis em doação, cessão de uso ou modalidade semelhante — especialmente terrenos sem benfeitorias e imóveis que demandem grandes reformas/adaptações ou investimento de capital — e também expedientes para transferir administração de imóveis nas mesmas condições. A OS prevê exceção: se a proposta for considerada altamente vantajosa, a OPM interessada deve, antes de iniciar o processo, consultar formalmente o órgão de direção setorial, expondo minuciosamente os motivos; o órgão setorial colhe parecer técnico do CIAP com estimativa dos custos de construção/reforma/adequação, manifesta-se e submete ao órgão de direção geral para deliberação do Subcomandante. A OS ainda trata de expedientes em diferentes estágios de tramitação. Como ato de 2017, verificar se foi revogado, substituído, flexibilizado ou complementado antes de tratá-lo como regra vigente.

A OS diz que expedientes já iniciados e não encaminhados ao órgão setorial deveriam permanecer custodiados na origem até nova deliberação; os já em órgão de direção geral/DFP deveriam ser devolvidos à origem; expedientes encaminhados à ATP/SSP para prosseguimento deveriam ser reanalisados pelo órgão de direção geral. A exceção de alta vantagem demanda justificativa específica e análise técnica dos custos, não simples manifestação de interesse.

## 4. Dossiê imobiliário comum às modalidades
Usar o checklist específico de cada modalidade e tipo de proprietário; os itens abaixo são um núcleo de conferência, não uma lista universal e invariável:

### 4.1 Titularidade, capacidade e situação jurídica
- Matrícula ou transcrição atualizada do imóvel, emitida pelo Cartório de Registro de Imóveis competente, em nome do proprietário/proponente; evitar cópias antigas.
- Título aquisitivo e cadeia dominial/filiação vintenária quando exigidos no checklist aplicável; certidões negativas de ônus, alienações e ações reipersecutórias conforme a modalidade e orientação jurídica. Os guias observam que registros anteriores a 1973 podem ser transcrições, não matrículas.
- Verificar se o proprietário tem poder de dispor do imóvel, se há gravames, coproprietários, usufruto, alienação fiduciária, restrições, necessidade de anuência conjugal, herdeiros ou terceiros, e se o bem está efetivamente disponível para o negócio.
- Para pessoa física: documentos de identificação e estado civil; outorga/anuência conjugal quando juridicamente exigível; poderes para assinar.
- Para pessoa jurídica privada: atos constitutivos e alterações, registro competente, CNPJ, regras de representação, ata/ato de nomeação de administrador e documentos pessoais do signatário; autorização societária se necessária; minuta/termo aprovado pelo representante competente ou jurídico quando previsto no checklist.
- Para município: lei/autorização legislativa e demais atos necessários conforme o instrumento. Na doação de imóvel municipal, o guia prevê, quando aplicável, lei de desafetação e autorização para doar à Fazenda Estadual; avaliar também certidão de área verde quando o imóvel tiver essa condição.
- Para autarquia: lei de criação, regimento interno, ato/ata de nomeação da diretoria, prova dos poderes de representação, manifestação prévia da Secretaria de Estado supervisora sobre a possibilidade de atender à solicitação e, se imóvel desapropriado, lei/decreto expropriatório e documentos de renúncia de preferência do expropriado/herdeiros quando exigíveis.
- Para imóvel da União: conferir regime dominial, competência da SPU/órgão federal, autorização e instrumentos federais aplicáveis; não aplicar automaticamente documentos exigidos para município ou autarquia estadual.

### 4.2 Cadastro, valor e características físicas
- Certidão/cadastro municipal do imóvel urbano; IPTU atualizado e comprovantes de quitação conforme o checklist e o caso; para imóvel rural, documentos do cadastro rural e ITR pertinentes.
- Certidão de valor venal/valor do imóvel quando exigida; avaliação técnica do CIAP, com área total e área construída, quando aplicável à modalidade.
- Relatório fotográfico; planta baixa indicando área do terreno e área construída; memorial descritivo; croqui de localização com endereço completo; extrato do cadastro do imóvel no SGI quando aplicável.
- Se ocupação parcial ou conjunta: planta/croqui deve identificar o imóvel integral e a parcela destinada à PMESP, áreas de cada órgão, acesso, limites e remanescente; juntar memorial descritivo da porção pretendida quando previsto. Uma planta da ocupação parcial não dispensa planta geral do imóvel quando exigida.
- Para imóvel com edificação, comparar áreas e descrição da matrícula, cadastro municipal, planta e vistoria. Divergências devem ser explicadas e corrigidas, não harmonizadas por suposição.
- A avaliação técnica do CIAP, conforme checklists, deve informar área total e construída e pode ser emitida/homologada pelo CIAP; distinguir avaliação técnica/condições físicas de avaliação econômica/valor de mercado, que podem ter finalidades diferentes.

### 4.3 Interesse público e encaminhamento
O ofício da OPM interessada deve descrever finalidade/necessidade operacional, unidade ou equipamento que se pretende instalar, modalidade e prazo pretendidos quando houver, dados identificadores do imóvel (proprietário, matrícula/transcrição, endereço, área total e construída), condições de uso e razões de interesse/conveniência pública. Em transferência, o guia pede informar o último órgão público ocupante, se houver, e a OPM beneficiária. O dirigente da UGE/órgão subsetorial encaminha processo saneado à instância superior/DF, avaliza a manifestação de interesse e trata expressamente das condições/obrigações do cedente e das responsabilidades financeiras advindas da administração do imóvel, conforme o checklist aplicável.

## 5. Procedimento por modalidade

### 5.1 Doação
**Objeto:** transferência de propriedade para a Fazenda Estadual, com uso destinado à PMESP.

**Doador pessoa física:** verificar identidade, estado civil/regime de bens e anuência conjugal quando aplicável; título e matrícula/transcrição atualizados; cadeia dominial/filiação e ônus conforme checklist; cadastro municipal, IPTU e valor; plantas, memorial, croqui, fotos e avaliação CIAP; manifestação inequívoca e formal de vontade de doar; condições/encargos da doação e prazo para cumprimento, se houver; poderes e regularidade do imóvel. Confirmar forma da escritura, aceitação, autorização estadual e registro imobiliário conforme a legislação vigente.

**Doador pessoa jurídica privada:** além do dossiê imobiliário, juntar contrato/estatuto social e alterações, registro, CNPJ, ata/ato de eleição ou nomeação dos administradores, documentos pessoais e prova dos poderes para doar/assinar; autorização societária se necessária; manifestação de vontade e minuta/escritura adequadas. O checklist contempla certidões do proprietário/empresa, inclusive fiscais, protestos e distribuidores, conforme os documentos e exigências jurídicas aplicáveis; verificar validade e pertinência atuais.

**Doador município:** verificar titularidade municipal, lei de desafetação se necessária, lei autorizativa da doação à Fazenda Estadual, atos do prefeito/representante, certidão de área verde quando pertinente, matrícula/transcrição, cadeia dominial e ônus, cadastro/valor, avaliação e dossiê físico. Não presumir que mera lei autorizativa transfere a propriedade: concluir formalização e registro conforme a via jurídica aprovada.

**Doador autarquia:** verificar lei de criação, regimento interno, ato de nomeação da diretoria e poderes para alienar/assinar; manifestação prévia da Secretaria supervisora; autorização legislativa/administrativa que for aplicável; tratamento específico de imóvel desapropriado, inclusive documentos da desapropriação e renúncia de preferência quando exigíveis; dossiê de titularidade, cadastro, avaliação e características físicas.

**Pontos críticos:** manifestação do doador não substitui prova de propriedade nem poderes para alienar; avaliação CIAP e valor venal não são necessariamente a mesma coisa; identificar encargos/condições, prazo de implantação e eventual custo de adequação; confirmar quem suporta despesas e providenciar escritura/registro/atualização patrimonial.

### 5.2 Cessão de uso / permissão de uso
**Objeto:** uso de imóvel público sem transferência de propriedade. Os checklists separados são específicos para imóvel de município, da União e de autarquia estadual; não combinar seus requisitos sem análise.

Conferir: prova de titularidade e de competência do ente/órgão para ceder; lei, decreto, autorização ou deliberação necessária; manifestação formal do ente cedente; matrícula/transcrição atualizada e cadeia dominial/ônus; cadastro municipal/IPTU ou documentos rurais aplicáveis; avaliação técnica CIAP; planta, memorial, fotos e croqui; área exata e uso pretendido; prazo; finalidade; eventual ocupação parcial/conjunta; encargos, conservação, benfeitorias, obras, seguros, tributos, despesas, responsabilidade por manutenção e condições de devolução; minuta de termo e aprovações competentes.

Para município, verificar autorização legislativa quando necessária e poderes do representante municipal. Para União, identificar órgão federal competente e requisitos federais próprios. Para autarquia estadual, confirmar capacidade e autorização segundo lei/regimento e supervisão. A cessão pode exigir termo formal e condições específicas; a permissão/autorização pode ter natureza e precariedade diferentes. A NT AGI nº 2/2020 é referência temática para outorga de uso, mas seu enquadramento e vigência devem ser conferidos.

### 5.3 Transferência de administração
**Objeto:** redistribuição administrativa de imóvel sob administração de outro órgão público, descrita nos guias como procedimento interno, em regra sem contrato civil, autorização legislativa ou anotação cartorária próprios da transferência de administração entre órgãos da Administração Direta; não generalizar essa descrição a todo caso sem conferir a natureza do imóvel e a norma atual.

Checklist típico: manifestação prévia do órgão público local que administra/detém o imóvel e, quando aplicável, da Secretaria de Estado detentora; matrícula/transcrição atualizada em nome da Fazenda Estadual; extrato SGI; avaliação técnica CIAP (área total e construída); relatório fotográfico; planta baixa; croqui; planta/croqui de ocupação parcial ou conjunta; memorial descritivo da porção pretendida quando parcial; ofício da OPM interessada e encaminhamento do dirigente da UGE/órgão superior. A vistoria CIAP pode ocorrer posteriormente conforme o checklist, então não declarar o processo completo antes de sua emissão.

O guia cita I-38-PM arts. 39–43, Nota Técnica CJ/SSP nº 618/2019, capítulo X, item X.3, subitem 82, e Decreto Estadual nº 39.980/1995, art. 7º, que atribui ao Governador autorização para transferência de administração entre Secretarias de Estado por decreto. Verificar texto consolidado e alçada atual; não presumir que todo expediente exige exatamente o mesmo ato ou que um fluxo histórico permanece inalterado.

Se o imóvel estiver sob posse de órgão da Administração Direta mas não for propriedade da Fazenda, investigar o título de posse e se a transferência de administração é juridicamente adequada. Se houver contrato anterior de comodato/cessão com terceiro proprietário, analisar necessidade de retificação, anuência ou outro instrumento antes de prosseguir.

### 5.4 Comodato
**Objeto:** empréstimo gratuito de imóvel de pessoa física ou pessoa jurídica de direito privado à Fazenda Estadual. Não utilizar comodato para bem de pessoa jurídica de direito público quando a modalidade apropriada for cessão, permissão ou autorização de uso.

Checklist típico: manifestação do comodante; prova de identidade/capacidade e poderes de representação; matrícula/transcrição atualizada em nome do comodante; filiação vintenária e certidão de ônus conforme checklist; cadastro municipal e IPTU/parcelas quitadas para imóvel urbano; documentos rurais/ITR quando pertinentes; fotos, memorial, planta baixa, croqui e dossiê de ocupação parcial; avaliação técnica CIAP; minuta do contrato e aprovações do signatário; encaminhamento da OPM e do dirigente da UGE com justificativa de interesse público, prazo e obrigações financeiras.

A gratuidade é elemento central: se houver contraprestação, pagamento pelo uso ou obrigação econômica que altere a natureza do negócio, reavaliar o enquadramento. Disciplinar prazo, uso, encargos, manutenção, benfeitorias, reparações, devolução, rescisão e responsabilidades. Os guias citam I-38-PM arts. 74–82 e, por remissão do Ofício GPG-Cons. Circular nº 2.896/2002, NT CJ/SSP nº 618/2019, capítulo VI, item VI.2, subitem 43, sobre cessão de uso com a Fazenda como cessionária; confirmar aplicabilidade atual.

O Guia Prático de Comodato recomenda, com base na I-38-PM citada, não aceitar comodatos com prazo definido inferior a 5 anos; considera preferível prazo de 20 anos ou mais, admite prazo indeterminado e recomenda avaliar cláusula de reparação caso haja devolução antecipada em comodato indeterminado. Trata-se de orientação do guia, não de regra universal a aplicar sem consultar a I-38-PM vigente, a alçada e a orientação jurídica. O guia também alerta contra cláusula de retomada em prazo muito curto (inferior a 90 dias), pois prejudicaria a segurança de permanência; conferir redação e aplicabilidade no caso concreto.

## 6. SGI — atualização e governança cadastral
A OS PM4-001/2.1/19, de 08FEV19, trata de atualização cadastral do Sistema de Gerenciamento de Imóveis (SGI) e cita os Decretos Estaduais nº 61.163/2015 e nº 64.030/2018. O documento de 2019 determina, naquele contexto: órgãos subsetoriais encaminharem dados de gestores e colaboradores à DF; cadastro e associação dos imóveis a gestores; limite de referência de até 20 imóveis por gestor, com justificativa fundamentada para ultrapassagem; atualização/complementação dos imóveis sob responsabilidade; e atualização sempre que necessária e obrigatoriamente uma vez ao ano até o último dia útil de julho. Também prevê justificativa hierárquica em até cinco dias quando não concluída no prazo. Prazos e fluxos devem ser conferidos contra regras atuais.

O Decreto nº 64.030/2018, reproduzido no anexo da OS, trata de atualização/complementação cadastral, designação de gestores/auxiliares/colaboradores, associação dos imóveis a gestores, validação cadastral e dever de manter o SGI atualizado. A atualização cadastral não substitui a regularização jurídica nem transfere propriedade/posse por si só.

Ao conferir SGI: validar número e endereço por documento; proprietário/administrador; órgão/UGE responsável; unidade ocupante; tipo de ocupação; área total e construída; gestor; situação e destinação; contrato/termo e prazo quando aplicável. Em transferência, usar o extrato SGI como uma das peças, comparando com matrícula e ato de administração. Não confundir SGI com SGPI (Sistema de Gestão do Patrimônio Imobiliário do Estado).

## 7. Regularização contra incêndio e segurança de edificações

### 7.1 NI PM4-002/2.1/19 — regularização de edificações de OPM
A NI tem como finalidade estabelecer sistemática para regularização de edificações policiais-militares junto ao Corpo de Bombeiros (CB), segundo o Regulamento de Segurança Contra Incêndio. Cita Lei Complementar Estadual nº 1.257/2015, Decreto Estadual nº 63.911/2018, I-38-PM (2017), OS PM4-001/2.1/19 e portaria/instruções técnicas do CB.

O documento distingue, entre outros: Projeto Técnico Simplificado (PTS) com AVCB/CLCB para edificações com área até 750 m² e até três pavimentos, ressalvadas as condições/ocupações especiais previstas na norma; e Projeto Técnico (PT) para os casos fora desses parâmetros ou em que a própria classificação da edificação exija PT. Não usar área/pavimentos isoladamente sem avaliar ocupação, riscos, compartimentação, uso conjunto e as Instruções Técnicas vigentes do CB.

A NI organiza a ação em etapas: designação de gestor pela OPM; levantamento/catálogo das edificações e ocupações; pesquisa no SGI e no sistema Via Fácil Bombeiros; verificação da existência/validade de AVCB/CLCB; vistoria prévia por Bombeiro, com planilha e croqui; identificação de medidas pendentes; planejamento e aquisição/instalação de sinalização, iluminação de emergência e extintores quando indicados; elaboração/cadastro de PTS ou contratação/execução de PT conforme o caso; ART/RRT e documentos técnicos quando aplicáveis; vistoria/avaliação de risco; emissão de AVCB/CLCB; atualização cadastral no SGI e afixação da licença em local visível. Os passos específicos variam conforme PTS/PT e a situação do imóvel.

### 7.2 Responsabilidades descritas na NI de 2019
- Gestor designado: coordenar regularização, reunir dados, solicitar vistoria prévia, manter documentos, acompanhar medidas e atualização cadastral.
- Cmt/Ch/Dir: controlar e fiscalizar processos das OPM subordinadas, providenciar materiais/recursos sob sua esfera, encaminhar relatório geral de acompanhamento nos prazos indicados pela NI e alinhar procedimentos com o gestor.
- DF: a NI descreve atribuições relacionadas a acesso/gestão de cadastro e recursos de materiais conforme sua estrutura à época; não inferir que a Divisão de Gestão de Bens Imóveis atual detenha isoladamente todas essas competências sem ato vigente.
- 4ª EM/PM: consolidação/encaminhamento de relatórios e disponibilização de orientações/modelos conforme a NI.
- CIAP: modelos e orientação técnica nos pontos indicados no documento.
- Corpo de Bombeiros: fiscalização, vistoria e emissão de AVCB/CLCB/atos correspondentes, conforme a legislação e a classificação do imóvel.

A NI prevê regularização de instalações ocupadas por OPM e também aborda ocupação conjunta, edificações com mais de uma OPM, instalações especiais e situações de risco. Em ocupação conjunta, definir o órgão de maior nível/competência responsável conforme a NI e o ato atual, sem duplicar ou omitir responsabilidade.

### 7.3 OS PM4-002/2.1/19 (18ABR19) — fiscalização de edificações e áreas de risco
A ordem reforça que, após o fim do período de adaptação citado no Decreto Estadual nº 63.911/2018, o Corpo de Bombeiros passou a fiscalizar edificações e áreas de risco, podendo aplicar penalidades e, conforme o risco, atuar ou interditar imóvel. Determina que Cmt/Ch/Dir adotem medidas internas para adequar instalações próprias e subordinadas, obter AVCB/CLCB e assessorar OPM territoriais na regularização quando necessário. Tratar como documento histórico de 2019 e confirmar legislação e instruções técnicas atuais.

### 7.4 Evidências a conferir
Para cada imóvel: classificação/uso e áreas; AVCB ou CLCB vigente; projeto aprovado/cadastrado; laudos e ART/RRT quando exigidos; vistoria e pendências; medidas de emergência; plano e responsável por adequações; risco de interdição; comprovação de execução e licença afixada. Um cadastro no SGI, um projeto ou uma vistoria prévia não equivalem à licença final. A avaliação patrimonial/administrativa não substitui o laudo ou a manifestação técnica do CB/CIAP/engenheiro habilitado.

## 8. Padrão de análise documental e estados de evidência
Usar, por requisito, um destes estados: **Comprovado no documento examinado**; **Relatado, mas não verificado**; **Pendente**; **Parcialmente atendido**; **Não verificável**; **Não aplicável (justificar)**. Quadro recomendado: requisito/documento; fundamento indicado na fonte; evidência e ID/link SEI; validade; estado; risco; providência; setor/responsável sugerido; dependência.

Checagens cruzadas mínimas: proprietário x matrícula; endereço x cadastro municipal/SGI; área x planta/memorial/avaliação; instrumento x natureza do proprietário; prazo x segurança de permanência e investimento; ocupação parcial x croqui/memorial; custos/encargos x manifestação da UGE; autorização do proprietário/ente x poderes de representação; condição física x vistoria CIAP/CB; licença contra incêndio x uso/área/validade; ato final x registro/atualização SGI.

## 9. Referências identificadas nos materiais — sujeitas a conferência de vigência
- I-38-PM, Instruções para Administração de Bens Imóveis, 2ª edição (2017): arts. 3º, 32–43, 39–43, 66, 74–82 e demais artigos citados pelos checklists.
- Guias Práticos PMESP: Doação; Cessão de Uso; Transferência de Administração; Comodato, com checklists e modelos.
- Nota Técnica CJ/SSP nº 119/2019 — doação/recebimento em doação de bens imóveis.
- Nota Técnica CJ/SSP nº 618/2019 — procedimentos de regularização de ocupação, incluindo cessão, comodato e transferência de administração conforme capítulos/subitens referenciados nos guias.
- Nota Técnica AGI nº 2/2020 — outorga de uso (cessão, permissão e autorização de uso de bens imóveis).
- Ofício GPG-Cons. Circular nº 2.896/2002 — instruções sobre assuntos patrimoniais imobiliários; guia de comodato o invoca para remissão às regras de cessão de uso.
- OS Subcmt PM-048/17 (05DEZ17) — suspensão temporária de recebimento de imóveis em determinadas condições, com exceção sujeita a justificativa e análise técnica.
- OS PM4-001/2.1/19 (08FEV19) — atualização cadastral do SGI, citando Decretos nº 61.163/2015 e nº 64.030/2018.
- NI PM4-002/2.1/19 — sistemática de regularização de edificações de OPM segundo regulamento de segurança contra incêndio.
- OS PM4-002/2.1/19 (18ABR19) — fiscalização de edificações e áreas de risco / regularização contra incêndio.
- Decreto Estadual nº 39.980/1995, art. 7º (conforme guias); Código Civil, arts. 104, 108, 538–541, 579–585, 1.228, 1.245 e 1.519 quando indicados; Lei nº 6.015/1973; LC Estadual nº 1.257/2015; Decreto Estadual nº 63.911/2018; Decretos nº 61.163/2015 e nº 64.030/2018.

## 10. Regras de segurança documental
- Não inventar números SEI/SGI, matrícula, área, endereço, proprietário, prazo, valor, nome de responsável, ato de autorização ou licença.
- Não transformar checklist antigo em declaração de obrigação atual sem validar vigência.
- Não confundir doação (transferência de propriedade), cessão/permissão (uso de bem público), comodato (empréstimo gratuito privado) e transferência de administração (redistribuição administrativa).
- Não declarar que o processo está regular, pronto para assinatura, apto a receber investimento ou livre de risco de interdição sem exame suficiente dos documentos e das regras vigentes.
- Não presumir que manifestação de interesse, vistoria, cadastro SGI, avaliação CIAP, matrícula, projeto ou licença substitua os demais documentos exigidos.
- Para dúvida jurídica, dominial, de competência, validade de ato, prazo ou forma de registro, apontar a questão e recomendar manifestação da assessoria jurídica/órgão técnico competente.
